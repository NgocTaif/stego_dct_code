import numpy as np
import sys

Q_Y = np.array([
    [16, 11, 10, 16, 24, 40, 51, 61],
    [12, 12, 14, 19, 26, 58, 60, 55],
    [14, 13, 16, 24, 40, 57, 69, 56],
    [14, 17, 22, 29, 51, 87, 80, 62],
    [18, 22, 37, 56, 68, 109, 103, 77],
    [24, 35, 55, 64, 81, 104, 113, 92],
    [49, 64, 78, 87, 103, 121, 120, 101],
    [72, 92, 95, 98, 112, 100, 103, 99]
])

def compute_TRT(matrix):
    T = np.array([
        [0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536, 0.3536],
        [0.4904, 0.4157, 0.2778, 0.0975, -0.0975, -0.2778, -0.4157, -0.4904],
        [0.4619, 0.1913, -0.1913, -0.4619, -0.4619, -0.1913, 0.1913, 0.4619],
        [0.4157, -0.0975, -0.4904, -0.2778, 0.2778, 0.4904, 0.0975, -0.4157],
        [0.3536, -0.3536, -0.3536, 0.3536, 0.3536, -0.3536, -0.3536, 0.3536],
        [0.2778, -0.4904, 0.0975, 0.4157, -0.4157, -0.0975, 0.4904, -0.2778],
        [0.1913, -0.4619, 0.4619, -0.1913, -0.1913, 0.4619, -0.4619, 0.1913],
        [0.0975, -0.2778, 0.4157, -0.4904, 0.4904, -0.4157, 0.2778, -0.0975]
    ])

    T_T = T.T 
    
    return np.dot(np.dot(T, matrix), T_T)

def reconstruct_pixel_matrix(input_file, output_file):

    dct_matrix = np.loadtxt(input_file, dtype=np.float64)

    R = Q_Y * dct_matrix

    N_new = np.round(compute_TRT(R)) + 128

    N_new = np.clip(N_new, 0, 255).astype(np.uint8)

    np.savetxt(output_file, N_new, fmt="%d")

    print(f"Tao thanh cong ma tran moi: '{output_file}'.")

input_file = sys.argv[1]
output_file = input_file

reconstruct_pixel_matrix(input_file, output_file)
